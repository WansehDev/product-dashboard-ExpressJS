/*
 *   This is a Model class for the users.
 *   @Author: Lance Parantar
 */
const EXPRESS_MODEL = require("../system/express_model");

class StudentModel extends EXPRESS_MODEL {
  async createUser(first_name, last_name, email, password, res = null) {
    return await this.runQuery(
      "INSERT INTO users (firstname, lastname, email, password, created_at, updated_at) VALUES ($1, $2, $3, $4, $5, $6);",
      [first_name, last_name, email, password, "NOW()", "NOW()"],
      res
    ).then((result) => {
      console.log("User created", result);
      return result;
    });
  }

  async getUser(email, res = null) {
    return await this.runQuery(
      "SELECT * FROM users WHERE email = $1",
      [email],
      res
    ).then((result) => {
      return result;
    });
  }
}

module.exports = new StudentModel();
